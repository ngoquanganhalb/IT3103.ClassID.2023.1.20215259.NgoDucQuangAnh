package com.mycompany.labt1;

import javax.swing.JOptionPane;

/**
 *
 * @author quang
 */
public class Dialog {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello");
        System.exit(0);
    }
}
