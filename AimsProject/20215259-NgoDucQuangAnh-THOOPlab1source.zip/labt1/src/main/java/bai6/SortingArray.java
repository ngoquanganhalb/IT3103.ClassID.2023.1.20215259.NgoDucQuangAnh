/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai6;

/**
 *
 * @author quang
 */
import java.util.Arrays;
public class SortingArray{
    public static void main(String[] args) {
        int[] numbers = {5, 12, 3, 18, 7, 15, 9};
        Arrays.sort(numbers);
        System.out.println("Sorted array: " + Arrays.toString(numbers));

        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }

        // Tính trung bình cộng các phần tử trong mảng
        double average = (double) sum / numbers.length;

        System.out.println("Sum of array elements: " + sum);
        System.out.println("Average of array elements: " + average);
    }
}
